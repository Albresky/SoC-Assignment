install RTL file and make .mcs file
===================================


For ddr200t:

make install  FPGA_NAME=ddr200t 

make mcs      FPGA_NAME=ddr200t 

================================


For mcu200t:

make install  FPGA_NAME=mcu200t 

make mcs      FPGA_NAME=mcu200t 

