.. _appendix:

Appendix
========

* **HBirdv2 E203 Core and SoC**: https://github.com/riscv-mcu/e203_hbirdv2

* **HBird SDK**: https://github.com/riscv-mcu/hbird-sdk

* **Nuclei RISCV Tools Download**: https://nucleisys.com/download.php

* **Nuclei Development Board**: https://nucleisys.com/developboard.php

* **Nuclei riscv-openocd**: https://github.com/riscv-mcu/riscv-openocd

* **Nuclei riscv-binutils-gdb**: https://github.com/riscv-mcu/riscv-binutils-gdb

* **Nuclei riscv-gnu-toolchain**: https://github.com/riscv-mcu/riscv-gnu-toolchain

* **Nuclei riscv-newlib**: https://github.com/riscv-mcu/riscv-newlib

* **Nuclei riscv-gcc**: https://github.com/riscv-mcu/riscv-gcc

* **Nuclei RISC-V IP Products**: https://www.nucleisys.com/product.php

* **RISC-V MCU Community Website**: http://www.rvmcu.com/

* **Nuclei RV University Program**: https://www.nucleisys.com/campus.php
